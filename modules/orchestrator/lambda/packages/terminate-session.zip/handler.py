"""
Lambda function: Terminate Lab Session
Releases AttackBox and deletes Guacamole connection
"""
import os
import json
from datetime import datetime
import sys
sys.path.append('/opt/python')

from utils import Response, get_env_variable, get_path_parameter
from db import SessionManager, PoolManager
from ec2 import stop_instance, tag_instance
from guacamole import delete_guacamole_connection, get_connection_by_session
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
SESSIONS_TABLE = get_env_variable('SESSIONS_TABLE')
POOL_TABLE = get_env_variable('POOL_TABLE')
GUACAMOLE_DB_SECRET = get_env_variable('GUACAMOLE_DB_SECRET')
GUACAMOLE_HOST = get_env_variable('GUACAMOLE_HOST')
ENVIRONMENT = get_env_variable('ENVIRONMENT')


def lambda_handler(event, context):
    """
    Terminate a lab session
    
    Path parameters:
    - session_id: The session ID to terminate
    """
    try:
        logger.info(f"Terminate session request: {json.dumps(event)}")
        
        # Get session ID from path
        session_id = get_path_parameter(event, 'session_id')
        
        # Initialize managers
        session_manager = SessionManager(SESSIONS_TABLE)
        pool_manager = PoolManager(POOL_TABLE)
        
        # Get session details
        session = session_manager.get_session(session_id)
        
        if not session:
            return Response.error(
                f"Session {session_id} not found",
                404,
                'NotFound'
            )
        
        # Check if session is already terminated
        if session['status'] == 'terminated':
            return Response.error(
                f"Session {session_id} is already terminated",
                400,
                'BadRequest'
            )
        
        attackbox_instance_id = session.get('attackbox_instance_id')
        guacamole_connection_id = session.get('guacamole_connection_id')
        
        # Delete Guacamole connection
        if guacamole_connection_id:
            try:
                logger.info(f"Deleting Guacamole connection {guacamole_connection_id}...")
                delete_guacamole_connection(
                    secret_arn=GUACAMOLE_DB_SECRET,
                    db_host=GUACAMOLE_HOST,
                    connection_id=guacamole_connection_id
                )
            except Exception as e:
                logger.error(f"Failed to delete Guacamole connection: {str(e)}")
                # Continue with cleanup even if this fails
        
        # Stop AttackBox instance and return to pool
        if attackbox_instance_id:
            try:
                logger.info(f"Stopping AttackBox {attackbox_instance_id}...")
                stop_instance(attackbox_instance_id)
                
                # Update pool status
                pool_manager.update_instance_status(
                    instance_id=attackbox_instance_id,
                    status='available',
                    session_id=None
                )
                
                # Remove session tags
                tag_instance(attackbox_instance_id, {
                    'Session': '',
                    'Student': '',
                    'LabType': '',
                    'LastUsed': datetime.utcnow().isoformat()
                })
                
            except Exception as e:
                logger.error(f"Failed to stop AttackBox: {str(e)}")
                # Continue with cleanup even if this fails
        
        # Update session status
        session_manager.update_session_status(
            session_id=session_id,
            status='terminated',
            additional_attrs={
                'terminated_at': int(datetime.utcnow().timestamp())
            }
        )
        
        response_data = {
            'session_id': session_id,
            'status': 'terminated',
            'terminated_at': datetime.utcnow().isoformat(),
            'duration_minutes': int((datetime.utcnow().timestamp() - session['created_at']) / 60)
        }
        
        logger.info(f"Session terminated successfully: {session_id}")
        return Response.success(response_data)
        
    except ValueError as e:
        return Response.error(str(e), 400, 'ValidationError')
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return Response.error(
            "An unexpected error occurred while terminating the session",
            500,
            'InternalServerError'
        )
