"""
Lambda function: Pool Manager
Monitors and manages AttackBox pool availability
Runs on a schedule (every 5 minutes via EventBridge)
"""
import os
import json
from datetime import datetime
import sys
sys.path.append('/opt/python')

from utils import Response, get_env_variable
from db import PoolManager
from ec2 import get_attackbox_pool_instances
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
POOL_TABLE = get_env_variable('POOL_TABLE')
ATTACKBOX_ASG_NAME = get_env_variable('ATTACKBOX_ASG_NAME')
MIN_AVAILABLE = int(get_env_variable('MIN_AVAILABLE', '3'))
ENVIRONMENT = get_env_variable('ENVIRONMENT')


def sync_pool_with_asg(pool_manager: PoolManager, asg_name: str):
    """Sync DynamoDB pool table with actual ASG instances"""
    try:
        # Get all instances from ASG
        asg_instances = get_attackbox_pool_instances(asg_name)
        
        # Get all instances from pool table
        pool_stats = pool_manager.get_pool_stats()
        
        logger.info(f"ASG has {len(asg_instances)} instances")
        logger.info(f"Pool table stats: {pool_stats}")
        
        # Register any new instances found in ASG
        for instance in asg_instances:
            instance_id = instance['instance_id']
            existing = pool_manager.get_instance(instance_id)
            
            if not existing:
                # New instance - register it
                logger.info(f"Registering new instance: {instance_id}")
                instance_data = {
                    'instance_id': instance_id,
                    'status': 'available' if instance['state'] == 'running' else 'stopped',
                    'instance_type': instance['instance_type'],
                    'private_ip': instance.get('private_ip', ''),
                    'last_used': int(datetime.utcnow().timestamp()),
                    'registered_at': int(datetime.utcnow().timestamp())
                }
                pool_manager.register_instance(instance_data)
            else:
                # Update status based on EC2 state
                ec2_state = instance['state']
                pool_status = existing['status']
                
                # Sync status if needed
                if ec2_state == 'stopped' and pool_status == 'in_use':
                    # Instance was stopped but marked as in-use - reset to available
                    logger.warning(f"Instance {instance_id} is stopped but marked in-use. Resetting.")
                    pool_manager.update_instance_status(instance_id, 'available')
                elif ec2_state == 'running' and pool_status == 'stopped':
                    # Instance is running but marked as stopped
                    logger.info(f"Instance {instance_id} is running but marked stopped. Updating.")
                    pool_manager.update_instance_status(instance_id, 'available')
                elif ec2_state == 'terminated':
                    # Instance is terminated - remove from pool
                    logger.info(f"Instance {instance_id} is terminated. Marking in pool.")
                    pool_manager.update_instance_status(instance_id, 'terminated')
        
        return True
    except Exception as e:
        logger.error(f"Failed to sync pool with ASG: {str(e)}")
        raise


def lambda_handler(event, context):
    """
    Pool manager - monitors and maintains AttackBox pool
    
    Can be invoked:
    1. By EventBridge schedule (automatic)
    2. Via API Gateway (manual check)
    """
    try:
        logger.info(f"Pool manager invoked: {json.dumps(event)}")
        
        # Initialize pool manager
        pool_manager = PoolManager(POOL_TABLE)
        
        # Sync pool with ASG
        sync_pool_with_asg(pool_manager, ATTACKBOX_ASG_NAME)
        
        # Get current pool statistics
        pool_stats = pool_manager.get_pool_stats()
        
        logger.info(f"Pool statistics: {pool_stats}")
        
        # Check if we need to adjust pool size
        available_count = pool_stats.get('available', 0) + pool_stats.get('stopped', 0)
        
        recommendations = []
        
        if available_count < MIN_AVAILABLE:
            shortage = MIN_AVAILABLE - available_count
            recommendations.append(f"Pool is below minimum threshold. Need {shortage} more instances.")
            logger.warning(f"Pool shortage: {shortage} instances needed")
        
        # Check for orphaned instances (in-use but no active session)
        # This would require querying sessions table - implement if needed
        
        # Prepare response
        response_data = {
            'pool_stats': pool_stats,
            'asg_name': ATTACKBOX_ASG_NAME,
            'minimum_required': MIN_AVAILABLE,
            'available_count': available_count,
            'is_healthy': available_count >= MIN_AVAILABLE,
            'recommendations': recommendations,
            'checked_at': datetime.utcnow().isoformat()
        }
        
        logger.info(f"Pool check completed: {response_data}")
        return Response.success(response_data)
        
    except Exception as e:
        logger.error(f"Pool manager error: {str(e)}", exc_info=True)
        return Response.error(
            "Pool manager encountered an error",
            500,
            'InternalServerError'
        )
