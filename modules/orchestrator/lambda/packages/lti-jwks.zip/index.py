"""
LTI JWKS Endpoint for CyberLab.

Provides the tool's public key set (JWKS) that platforms use to verify
signatures on Deep Linking responses and other tool-signed messages.

For LTI 1.3, the platform needs to know the tool's public key to verify
JWT signatures from the tool (e.g., Deep Linking responses).
"""

import json
import logging
import os
from typing import Any, Dict

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Tool key configuration
# In production, these would be stored in AWS Secrets Manager or KMS
TOOL_KID = os.environ.get("TOOL_KEY_ID", "cyberlab-lti-key-1")


def json_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a JSON response for API Gateway."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Cache-Control": "public, max-age=3600",  # Cache for 1 hour
        },
        "body": json.dumps(body),
    }


def get_jwks() -> Dict[str, Any]:
    """
    Get the tool's JSON Web Key Set.
    
    In a production implementation, you would:
    1. Generate an RSA key pair during deployment
    2. Store the private key in AWS Secrets Manager
    3. Store the public key components here
    
    For basic LTI 1.3 resource link launches (what we need for CyberLab),
    the tool doesn't need to sign JWTs. The JWKS endpoint is primarily
    needed for:
    - Deep Linking responses (tool → platform)
    - Grade passback (LTI Assignment and Grade Services)
    
    Since our initial implementation only handles resource link launches
    (platform → tool), this endpoint can return an empty key set.
    """
    
    # Check if we have a configured public key
    public_key_n = os.environ.get("TOOL_PUBLIC_KEY_N", "")
    public_key_e = os.environ.get("TOOL_PUBLIC_KEY_E", "AQAB")
    
    if public_key_n:
        return {
            "keys": [
                {
                    "kty": "RSA",
                    "alg": "RS256",
                    "use": "sig",
                    "kid": TOOL_KID,
                    "n": public_key_n,
                    "e": public_key_e,
                }
            ]
        }
    
    # Return empty key set if no keys configured
    # This is valid for resource link launches only
    return {"keys": []}


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for JWKS endpoint.
    
    GET /lti/jwks - Returns the tool's public key set
    """
    logger.info("JWKS endpoint requested")
    
    method = event.get("requestContext", {}).get("http", {}).get("method", 
              event.get("httpMethod", "GET"))
    
    if method == "OPTIONS":
        return json_response(200, {})
    
    if method != "GET":
        return json_response(405, {"error": "Method not allowed"})
    
    jwks = get_jwks()
    
    return json_response(200, jwks)

