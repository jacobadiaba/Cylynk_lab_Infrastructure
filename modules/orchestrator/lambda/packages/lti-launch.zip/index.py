"""
LTI 1.3 Launch Handler for CyberLab.

Handles both:
1. OIDC Login Initiation (GET /lti/login)
2. Resource Link Launch (POST /lti/launch)

Flow:
1. Moodle sends login initiation to /lti/login
2. Tool redirects to Moodle auth endpoint
3. Moodle authenticates user and POSTs id_token to /lti/launch
4. Tool validates token and creates/retrieves session
5. Tool renders launch page with AttackBox access
"""

import json
import logging
import os
import time
import urllib.parse
from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import ClientError

# Import from Lambda layer
import sys
sys.path.insert(0, '/opt/python')

try:
    from common.utils import (
        DynamoDBClient, EC2Client, AutoScalingClient, GuacamoleClient,
        generate_session_id, get_current_timestamp, calculate_expiry,
        get_iso_timestamp, SessionStatus, InstanceStatus, logger
    )
    from common.lti_utils import (
        LTIPlatformConfig, LTILaunchData, JWTDecoder,
        generate_state, generate_nonce,
        build_oidc_login_response, validate_id_token_claims,
        render_launch_page, render_error_page,
        CLAIM_ISS, CLAIM_SUB, CLAIM_AUD
    )
except ImportError:
    # Fallback for local testing
    from utils import (
        DynamoDBClient, EC2Client, AutoScalingClient, GuacamoleClient,
        generate_session_id, get_current_timestamp, calculate_expiry,
        get_iso_timestamp, SessionStatus, InstanceStatus
    )
    from lti_utils import (
        LTIPlatformConfig, LTILaunchData, JWTDecoder,
        generate_state, generate_nonce,
        build_oidc_login_response, validate_id_token_claims,
        render_launch_page, render_error_page,
        CLAIM_ISS, CLAIM_SUB, CLAIM_AUD
    )
    logger = logging.getLogger()

logger.setLevel(logging.INFO)

# Environment variables
SESSIONS_TABLE = os.environ.get("SESSIONS_TABLE", "cyberlab-sessions")
INSTANCE_POOL_TABLE = os.environ.get("INSTANCE_POOL_TABLE", "cyberlab-instance-pool")
LTI_STATE_TABLE = os.environ.get("LTI_STATE_TABLE", "cyberlab-lti-state")
LTI_PLATFORMS_TABLE = os.environ.get("LTI_PLATFORMS_TABLE", "cyberlab-lti-platforms")
ASG_NAME = os.environ.get("ASG_NAME", "")
GUACAMOLE_PRIVATE_IP = os.environ.get("GUACAMOLE_PRIVATE_IP", "")
GUACAMOLE_PUBLIC_IP = os.environ.get("GUACAMOLE_PUBLIC_IP", "")
GUACAMOLE_ADMIN_USER = os.environ.get("GUACAMOLE_ADMIN_USER", "guacadmin")
GUACAMOLE_ADMIN_PASS = os.environ.get("GUACAMOLE_ADMIN_PASS", "guacadmin")
RDP_USERNAME = os.environ.get("RDP_USERNAME", "kali")
RDP_PASSWORD = os.environ.get("RDP_PASSWORD", "kali")
SESSION_TTL_HOURS = int(os.environ.get("SESSION_TTL_HOURS", "4"))
TOOL_URL = os.environ.get("TOOL_URL", "")  # Base URL for redirects
API_BASE_URL = os.environ.get("API_BASE_URL", "")  # API Gateway URL


def html_response(status_code: int, body: str) -> Dict[str, Any]:
    """Create an HTML response for API Gateway."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-store",
        },
        "body": body,
    }


def redirect_response(location: str) -> Dict[str, Any]:
    """Create a redirect response."""
    return {
        "statusCode": 302,
        "headers": {
            "Location": location,
            "Cache-Control": "no-store",
        },
        "body": "",
    }


def get_platform_config(issuer: str) -> Optional[LTIPlatformConfig]:
    """
    Get platform configuration from DynamoDB.
    
    In production, store these in DynamoDB during LTI registration.
    For now, check environment variables for a single platform.
    """
    # Check for environment-based config (simpler setup)
    moodle_url = os.environ.get("MOODLE_URL", "")
    moodle_client_id = os.environ.get("MOODLE_CLIENT_ID", "")
    moodle_deployment_id = os.environ.get("MOODLE_DEPLOYMENT_ID", "")
    
    if moodle_url and moodle_client_id:
        # Normalize issuer URLs for comparison
        moodle_issuer = moodle_url.rstrip("/")
        check_issuer = issuer.rstrip("/")
        
        if check_issuer == moodle_issuer or check_issuer.startswith(moodle_issuer):
            return LTIPlatformConfig(
                platform_id="moodle",
                client_id=moodle_client_id,
                deployment_id=moodle_deployment_id,
                iss=moodle_issuer,
                auth_login_url=f"{moodle_issuer}/mod/lti/auth.php",
                auth_token_url=f"{moodle_issuer}/mod/lti/token.php",
                jwks_url=f"{moodle_issuer}/mod/lti/certs.php",
            )
    
    # Try DynamoDB lookup
    try:
        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table(LTI_PLATFORMS_TABLE)
        response = table.get_item(Key={"issuer": issuer})
        if "Item" in response:
            return LTIPlatformConfig.from_dict(response["Item"])
    except Exception as e:
        logger.warning(f"Failed to lookup platform config: {e}")
    
    return None


def store_lti_state(state: str, data: Dict[str, Any]) -> bool:
    """Store state for OIDC flow."""
    try:
        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table(LTI_STATE_TABLE)
        table.put_item(
            Item={
                "state": state,
                "data": data,
                "created_at": get_current_timestamp(),
                "expires_at": get_current_timestamp() + 600,  # 10 min TTL
            }
        )
        return True
    except Exception as e:
        logger.error(f"Failed to store state: {e}")
        return False


def get_lti_state(state: str) -> Optional[Dict[str, Any]]:
    """Retrieve and delete state."""
    try:
        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table(LTI_STATE_TABLE)
        response = table.get_item(Key={"state": state})
        if "Item" in response:
            table.delete_item(Key={"state": state})
            return response["Item"].get("data")
    except Exception as e:
        logger.error(f"Failed to get state: {e}")
    return None


def handle_login_initiation(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle OIDC Login Initiation (Step 1 of LTI 1.3).
    
    Moodle POSTs to /lti/login with:
    - iss: Issuer (Moodle URL)
    - login_hint: Opaque user identifier
    - target_link_uri: Where to redirect after auth
    - lti_message_hint: (optional) Context for the launch
    - client_id: (optional) Tool client ID
    """
    # Parse form data (Moodle sends as application/x-www-form-urlencoded)
    body = event.get("body", "")
    if event.get("isBase64Encoded"):
        import base64
        body = base64.b64decode(body).decode("utf-8")
    
    # Handle both GET (query params) and POST (form data)
    if event.get("httpMethod", event.get("requestContext", {}).get("http", {}).get("method")) == "GET":
        params = event.get("queryStringParameters", {}) or {}
    else:
        params = dict(urllib.parse.parse_qsl(body))
    
    issuer = params.get("iss", "")
    login_hint = params.get("login_hint", "")
    target_link_uri = params.get("target_link_uri", "")
    lti_message_hint = params.get("lti_message_hint")
    client_id = params.get("client_id")
    
    logger.info(f"LTI Login initiation from issuer: {issuer}")
    
    if not issuer or not login_hint:
        return html_response(400, render_error_page(
            "Invalid Login Request",
            "Missing required parameters (issuer or login_hint)."
        ))
    
    # Get platform configuration
    platform_config = get_platform_config(issuer)
    if not platform_config:
        logger.error(f"Unknown LTI platform: {issuer}")
        return html_response(400, render_error_page(
            "Unknown Platform",
            f"The LTI platform '{issuer}' is not registered."
        ))
    
    # Override client_id if provided in request
    if client_id:
        platform_config.client_id = client_id
    
    # Generate state and nonce for security
    state = generate_state()
    nonce = generate_nonce()
    
    # Store state for validation in callback
    state_data = {
        "nonce": nonce,
        "issuer": issuer,
        "client_id": platform_config.client_id,
        "target_link_uri": target_link_uri,
    }
    
    if not store_lti_state(state, state_data):
        return html_response(500, render_error_page(
            "Server Error",
            "Failed to initialize authentication."
        ))
    
    # Build redirect URL
    redirect_uri = TOOL_URL.rstrip("/") + "/lti/launch" if TOOL_URL else target_link_uri
    
    auth_url = build_oidc_login_response(
        platform_config=platform_config,
        login_hint=login_hint,
        lti_message_hint=lti_message_hint,
        target_link_uri=target_link_uri,
        state=state,
        nonce=nonce,
        redirect_uri=redirect_uri,
    )
    
    logger.info(f"Redirecting to platform auth: {platform_config.auth_login_url}")
    
    return redirect_response(auth_url)


def handle_launch(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle LTI Resource Link Launch (Step 3 of LTI 1.3).
    
    Moodle POSTs id_token after user authentication.
    """
    # Parse form data
    body = event.get("body", "")
    if event.get("isBase64Encoded"):
        import base64
        body = base64.b64decode(body).decode("utf-8")
    
    params = dict(urllib.parse.parse_qsl(body))
    
    id_token = params.get("id_token", "")
    state = params.get("state", "")
    
    if not id_token:
        return html_response(400, render_error_page(
            "Missing Token",
            "No id_token provided in the launch request."
        ))
    
    # Decode JWT (without signature verification first to get issuer)
    try:
        header, claims, signature = JWTDecoder.decode_without_verification(id_token)
    except Exception as e:
        logger.error(f"Failed to decode JWT: {e}")
        return html_response(400, render_error_page(
            "Invalid Token",
            "The authentication token could not be decoded."
        ))
    
    issuer = claims.get(CLAIM_ISS, "")
    logger.info(f"LTI Launch from issuer: {issuer}, sub: {claims.get(CLAIM_SUB)}")
    
    # Get platform config
    platform_config = get_platform_config(issuer)
    if not platform_config:
        return html_response(400, render_error_page(
            "Unknown Platform",
            f"The LTI platform '{issuer}' is not registered."
        ))
    
    # Validate state if provided
    stored_nonce = None
    if state:
        state_data = get_lti_state(state)
        if state_data:
            stored_nonce = state_data.get("nonce")
        else:
            logger.warning("State not found or expired")
    
    # TODO: In production, verify JWT signature using platform's JWKS
    # For now, we validate claims without cryptographic verification
    # This is acceptable for internal/trusted deployments but NOT for production
    
    # Validate claims
    nonce_to_check = claims.get("nonce", stored_nonce or "")
    is_valid, error_msg = validate_id_token_claims(
        claims=claims,
        expected_nonce=nonce_to_check,
        client_id=platform_config.client_id,
        deployment_id=platform_config.deployment_id if platform_config.deployment_id else None,
    )
    
    # For testing, be more lenient with nonce validation if state wasn't provided
    if not is_valid and "nonce" in error_msg.lower() and not state:
        logger.warning("Skipping nonce validation (no state provided)")
        is_valid = True
    
    if not is_valid:
        logger.error(f"Token validation failed: {error_msg}")
        return html_response(400, render_error_page(
            "Invalid Token",
            f"Token validation failed: {error_msg}"
        ))
    
    # Parse LTI data
    launch_data = LTILaunchData(claims)
    
    logger.info(f"LTI Launch - User: {launch_data.display_name}, Course: {launch_data.course_name}")
    
    # Create or get existing session
    session_data = create_or_get_session(launch_data)
    
    if not session_data:
        return html_response(500, render_error_page(
            "Session Error",
            "Failed to create lab session. Please try again.",
            launch_data.return_url
        ))
    
    # Build Guacamole URL
    guacamole_url = session_data.get("connection_info", {}).get("direct_url", "#")
    
    # Render launch page
    page_html = render_launch_page(
        session_data=session_data,
        launch_data=launch_data,
        guacamole_url=guacamole_url,
        api_base_url=API_BASE_URL,
    )
    
    return html_response(200, page_html)


def create_or_get_session(launch_data: LTILaunchData) -> Optional[Dict[str, Any]]:
    """
    Create a new session or return existing one for the student.
    
    This mirrors the logic from create-session Lambda but is integrated here
    for LTI launches to provide a seamless experience.
    """
    sessions_db = DynamoDBClient(SESSIONS_TABLE)
    pool_db = DynamoDBClient(INSTANCE_POOL_TABLE)
    
    # Check for existing active session for this student
    student_id = launch_data.user_id
    existing_sessions = sessions_db.query_by_index("StudentIndex", "student_id", student_id)
    
    for session in existing_sessions:
        if session.get("status") in [SessionStatus.PENDING, SessionStatus.PROVISIONING, 
                                      SessionStatus.READY, SessionStatus.ACTIVE]:
            logger.info(f"Found existing session for student {student_id}: {session.get('session_id')}")
            return session
    
    # Find an available instance
    asg_client = AutoScalingClient()
    ec2_client = EC2Client()
    
    # Get instances from ASG
    asg_instances = asg_client.get_asg_instances(ASG_NAME)
    
    available_instance = None
    for asg_instance in asg_instances:
        instance_id = asg_instance.get("InstanceId")
        if asg_instance.get("LifecycleState") != "InService":
            continue
        
        # Check pool status
        pool_entry = pool_db.get_item({"instance_id": instance_id})
        if pool_entry and pool_entry.get("status") == InstanceStatus.AVAILABLE:
            available_instance = instance_id
            break
        elif not pool_entry:
            # New instance, add to pool and use it
            pool_db.put_item({
                "instance_id": instance_id,
                "status": InstanceStatus.AVAILABLE,
                "created_at": get_iso_timestamp(),
            })
            available_instance = instance_id
            break
    
    if not available_instance:
        logger.error("No available instances in pool")
        return None
    
    # Get instance details
    instance_info = ec2_client.get_instance_status(available_instance)
    if not instance_info:
        logger.error(f"Could not get instance info for {available_instance}")
        return None
    
    instance_ip = instance_info.get("PrivateIpAddress", "")
    
    # Create Guacamole connection
    guacamole_url = f"https://{GUACAMOLE_PUBLIC_IP}/guacamole"
    guac_client = GuacamoleClient(guacamole_url, GUACAMOLE_ADMIN_USER, GUACAMOLE_ADMIN_PASS)
    
    session_id = generate_session_id()
    connection_name = f"Lab-{session_id[-8:]}-{launch_data.display_name[:20]}"
    
    connection_id = guac_client.create_rdp_connection(
        name=connection_name,
        hostname=instance_ip,
        port=3389,
        username=RDP_USERNAME,
        password=RDP_PASSWORD,
        security="any",
        ignore_cert=True,
    )
    
    if not connection_id:
        logger.error("Failed to create Guacamole connection")
        return None
    
    # Create session user and get direct URL
    direct_url = guac_client.create_session_user_and_get_url(
        session_id=session_id,
        connection_id=connection_id,
        student_id=student_id,
    )
    
    if not direct_url:
        # Fallback to connection URL without session user
        direct_url = guac_client.get_connection_with_token_url(connection_id)
    
    # Mark instance as assigned
    pool_db.update_item(
        {"instance_id": available_instance},
        {
            "status": InstanceStatus.ASSIGNED,
            "session_id": session_id,
            "assigned_at": get_iso_timestamp(),
        }
    )
    
    # Tag the instance
    ec2_client.tag_instance(available_instance, {
        "Session": session_id,
        "Student": student_id,
        "Course": launch_data.course_id,
    })
    
    # Create session record
    session_data = {
        "session_id": session_id,
        "student_id": student_id,
        "student_name": launch_data.display_name,
        "student_email": launch_data.email,
        "course_id": launch_data.course_id,
        "course_name": launch_data.course_name,
        "lab_id": launch_data.lab_id,
        "lab_type": launch_data.lab_type,
        "instance_id": available_instance,
        "status": SessionStatus.READY,
        "created_at": get_iso_timestamp(),
        "expires_at": calculate_expiry(SESSION_TTL_HOURS),
        "connection_info": {
            "guacamole_connection_id": connection_id,
            "direct_url": direct_url,
            "rdp_host": instance_ip,
            "rdp_port": 3389,
        },
        "lti_metadata": {
            "issuer": launch_data.issuer,
            "deployment_id": launch_data.deployment_id,
            "resource_link_id": launch_data.resource_link_id,
            "return_url": launch_data.return_url,
        }
    }
    
    sessions_db.put_item(session_data)
    
    logger.info(f"Created session {session_id} for student {student_id}")
    
    return session_data


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for LTI endpoints.
    
    Routes:
    - GET/POST /lti/login - OIDC Login Initiation
    - POST /lti/launch - Resource Link Launch
    """
    logger.info(f"LTI Handler invoked: {json.dumps(event, default=str)[:500]}")
    
    # Get HTTP method and path
    request_context = event.get("requestContext", {})
    http_info = request_context.get("http", {})
    
    method = http_info.get("method", event.get("httpMethod", "POST"))
    path = http_info.get("path", event.get("path", ""))
    
    # Route based on path
    if "/lti/login" in path:
        return handle_login_initiation(event)
    elif "/lti/launch" in path:
        return handle_launch(event)
    else:
        # Default: treat as launch (for flexibility)
        return handle_launch(event)

