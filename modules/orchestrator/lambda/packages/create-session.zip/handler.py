"""
Lambda function: Create Lab Session
Allocates an AttackBox and creates Guacamole connection
"""
import os
import json
import uuid
from datetime import datetime
import sys
sys.path.append('/opt/python')  # Lambda layer path

from utils import Response, get_env_variable, calculate_ttl, parse_request_body
from db import SessionManager, PoolManager
from ec2 import find_available_attackbox, get_instance_details, tag_instance
from guacamole import create_guacamole_connection
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
SESSIONS_TABLE = get_env_variable('SESSIONS_TABLE')
POOL_TABLE = get_env_variable('POOL_TABLE')
GUACAMOLE_DB_SECRET = get_env_variable('GUACAMOLE_DB_SECRET')
GUACAMOLE_HOST = get_env_variable('GUACAMOLE_HOST')
ATTACKBOX_ASG_NAME = get_env_variable('ATTACKBOX_ASG_NAME')
SESSION_TIMEOUT_HOURS = int(get_env_variable('SESSION_TIMEOUT_HOURS', '4'))
ENVIRONMENT = get_env_variable('ENVIRONMENT')


def lambda_handler(event, context):
    """
    Create a new lab session
    
    Request body:
    {
        "student_id": "string",
        "student_email": "string",
        "lab_type": "pentest|forensics|general",
        "session_timeout_hours": 4 (optional),
        "protocol": "rdp|vnc" (optional, default: vnc)
    }
    """
    try:
        logger.info(f"Create session request: {json.dumps(event)}")
        
        # Parse request
        body = parse_request_body(event)
        
        # Validate required fields
        required_fields = ['student_id', 'student_email']
        for field in required_fields:
            if field not in body:
                return Response.error(f"Missing required field: {field}", 400)
        
        student_id = body['student_id']
        student_email = body['student_email']
        lab_type = body.get('lab_type', 'general')
        timeout_hours = body.get('session_timeout_hours', SESSION_TIMEOUT_HOURS)
        protocol = body.get('protocol', 'vnc')
        
        # Validate protocol
        if protocol not in ['rdp', 'vnc']:
            return Response.error("Protocol must be 'rdp' or 'vnc'", 400)
        
        # Initialize managers
        session_manager = SessionManager(SESSIONS_TABLE)
        pool_manager = PoolManager(POOL_TABLE)
        
        # Check if student already has an active session
        active_sessions = session_manager.get_active_sessions_by_student(student_id)
        if active_sessions:
            return Response.error(
                f"Student already has {len(active_sessions)} active session(s). Please terminate existing sessions first.",
                409
            )
        
        # Find available AttackBox
        logger.info("Finding available AttackBox...")
        available_instances = pool_manager.get_available_instances()
        
        if not available_instances:
            return Response.error(
                "No AttackBox instances available. Please try again later.",
                503,
                'ServiceUnavailable'
            )
        
        attackbox_instance_id = find_available_attackbox(ATTACKBOX_ASG_NAME, available_instances)
        
        if not attackbox_instance_id:
            return Response.error(
                "Failed to allocate AttackBox. Please try again later.",
                503,
                'ServiceUnavailable'
            )
        
        # Get instance details
        instance_details = get_instance_details(attackbox_instance_id)
        if not instance_details:
            return Response.error(
                "Failed to get AttackBox details",
                500,
                'InternalServerError'
            )
        
        # Wait for instance to be running (if we just started it)
        # In production, consider using Step Functions for async workflow
        
        # Generate session ID
        session_id = str(uuid.uuid4())
        
        # Create Guacamole connection
        logger.info(f"Creating Guacamole {protocol.upper()} connection...")
        connection_name = f"{student_id}-{lab_type}-{session_id[:8]}"
        
        # AttackBox credentials (these should be from your AttackBox setup)
        attackbox_username = 'kali'  # Default Kali username
        attackbox_password = 'kali'  # Should be from Secrets Manager in production
        
        # Determine port based on protocol
        port = 3389 if protocol == 'rdp' else 5901
        
        try:
            guacamole_connection_id = create_guacamole_connection(
                secret_arn=GUACAMOLE_DB_SECRET,
                db_host=GUACAMOLE_HOST,
                connection_name=connection_name,
                protocol=protocol,
                hostname=instance_details['private_ip'],
                port=port,
                username=attackbox_username,
                password=attackbox_password,
                session_id=session_id
            )
        except Exception as e:
            logger.error(f"Failed to create Guacamole connection: {str(e)}")
            return Response.error(
                "Failed to create remote access connection",
                500,
                'InternalServerError'
            )
        
        # Update pool - mark instance as in-use
        pool_manager.update_instance_status(
            instance_id=attackbox_instance_id,
            status='in_use',
            session_id=session_id
        )
        
        # Tag EC2 instance
        tag_instance(attackbox_instance_id, {
            'Session': session_id,
            'Student': student_id,
            'LabType': lab_type
        })
        
        # Create session record
        current_timestamp = int(datetime.utcnow().timestamp())
        session_data = {
            'session_id': session_id,
            'student_id': student_id,
            'student_email': student_email,
            'lab_type': lab_type,
            'attackbox_instance_id': attackbox_instance_id,
            'attackbox_private_ip': instance_details['private_ip'],
            'guacamole_connection_id': guacamole_connection_id,
            'protocol': protocol,
            'status': 'active',
            'created_at': current_timestamp,
            'updated_at': current_timestamp,
            'expires_at': current_timestamp + (timeout_hours * 3600),
            'ttl': calculate_ttl(timeout_hours + 24),  # Keep record for 24h after expiry
            'environment': ENVIRONMENT
        }
        
        session_manager.create_session(session_data)
        
        # Prepare response
        guacamole_url = f"https://{GUACAMOLE_HOST}/#/client/{guacamole_connection_id}"
        
        response_data = {
            'session_id': session_id,
            'status': 'active',
            'attackbox': {
                'instance_id': attackbox_instance_id,
                'private_ip': instance_details['private_ip'],
                'instance_type': instance_details['instance_type']
            },
            'access': {
                'protocol': protocol,
                'guacamole_url': guacamole_url,
                'guacamole_connection_id': guacamole_connection_id
            },
            'session_info': {
                'created_at': datetime.fromtimestamp(current_timestamp).isoformat(),
                'expires_at': datetime.fromtimestamp(session_data['expires_at']).isoformat(),
                'timeout_hours': timeout_hours
            }
        }
        
        logger.info(f"Session created successfully: {session_id}")
        return Response.success(response_data, 201)
        
    except ValueError as e:
        return Response.error(str(e), 400, 'ValidationError')
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return Response.error(
            "An unexpected error occurred. Please try again later.",
            500,
            'InternalServerError'
        )
