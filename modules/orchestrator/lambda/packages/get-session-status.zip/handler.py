"""
Lambda function: Get Session Status
Retrieves current session information
"""
import os
import json
from datetime import datetime
import sys
sys.path.append('/opt/python')

from utils import Response, get_env_variable, get_path_parameter
from db import SessionManager
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
SESSIONS_TABLE = get_env_variable('SESSIONS_TABLE')
ENVIRONMENT = get_env_variable('ENVIRONMENT')


def lambda_handler(event, context):
    """
    Get session status
    
    Path parameters:
    - session_id: The session ID to query
    """
    try:
        logger.info(f"Get session status request: {json.dumps(event)}")
        
        # Get session ID from path
        session_id = get_path_parameter(event, 'session_id')
        
        # Initialize session manager
        session_manager = SessionManager(SESSIONS_TABLE)
        
        # Get session details
        session = session_manager.get_session(session_id)
        
        if not session:
            return Response.error(
                f"Session {session_id} not found",
                404,
                'NotFound'
            )
        
        # Calculate time remaining
        current_time = int(datetime.utcnow().timestamp())
        time_remaining_seconds = max(0, session['expires_at'] - current_time)
        time_elapsed_seconds = current_time - session['created_at']
        
        # Prepare response
        response_data = {
            'session_id': session['session_id'],
            'student_id': session['student_id'],
            'student_email': session['student_email'],
            'lab_type': session['lab_type'],
            'status': session['status'],
            'attackbox': {
                'instance_id': session.get('attackbox_instance_id'),
                'private_ip': session.get('attackbox_private_ip')
            },
            'access': {
                'protocol': session.get('protocol'),
                'guacamole_connection_id': session.get('guacamole_connection_id')
            },
            'timing': {
                'created_at': datetime.fromtimestamp(session['created_at']).isoformat(),
                'expires_at': datetime.fromtimestamp(session['expires_at']).isoformat(),
                'time_elapsed_minutes': int(time_elapsed_seconds / 60),
                'time_remaining_minutes': int(time_remaining_seconds / 60),
                'is_expired': time_remaining_seconds == 0
            }
        }
        
        # Add termination info if terminated
        if session['status'] == 'terminated' and 'terminated_at' in session:
            response_data['terminated_at'] = datetime.fromtimestamp(session['terminated_at']).isoformat()
        
        logger.info(f"Session status retrieved: {session_id}")
        return Response.success(response_data)
        
    except ValueError as e:
        return Response.error(str(e), 400, 'ValidationError')
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return Response.error(
            "An unexpected error occurred while retrieving session status",
            500,
            'InternalServerError'
        )
