"""
EC2 operations for AttackBox management
"""
import boto3
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger()

ec2_client = boto3.client('ec2')
autoscaling_client = boto3.client('autoscaling')


def get_instance_details(instance_id: str) -> Optional[Dict[str, Any]]:
    """Get EC2 instance details"""
    try:
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if not response['Reservations']:
            return None
        
        instance = response['Reservations'][0]['Instances'][0]
        return {
            'instance_id': instance['InstanceId'],
            'state': instance['State']['Name'],
            'private_ip': instance.get('PrivateIpAddress'),
            'launch_time': instance['LaunchTime'].isoformat(),
            'instance_type': instance['InstanceType']
        }
    except Exception as e:
        logger.error(f"Failed to get instance details for {instance_id}: {str(e)}")
        raise


def start_instance(instance_id: str) -> bool:
    """Start a stopped EC2 instance"""
    try:
        response = ec2_client.start_instances(InstanceIds=[instance_id])
        logger.info(f"Started instance {instance_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to start instance {instance_id}: {str(e)}")
        raise


def stop_instance(instance_id: str) -> bool:
    """Stop a running EC2 instance"""
    try:
        response = ec2_client.stop_instances(InstanceIds=[instance_id])
        logger.info(f"Stopped instance {instance_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to stop instance {instance_id}: {str(e)}")
        raise


def get_attackbox_pool_instances(asg_name: str) -> List[Dict[str, Any]]:
    """Get all instances in the AttackBox Auto Scaling Group"""
    try:
        response = autoscaling_client.describe_auto_scaling_groups(
            AutoScalingGroupNames=[asg_name]
        )
        
        if not response['AutoScalingGroups']:
            logger.warning(f"Auto Scaling Group {asg_name} not found")
            return []
        
        asg = response['AutoScalingGroups'][0]
        instances = []
        
        for instance in asg['Instances']:
            instance_id = instance['InstanceId']
            details = get_instance_details(instance_id)
            if details:
                details['lifecycle_state'] = instance['LifecycleState']
                details['health_status'] = instance['HealthStatus']
                instances.append(details)
        
        return instances
    except Exception as e:
        logger.error(f"Failed to get ASG instances: {str(e)}")
        raise


def find_available_attackbox(asg_name: str, pool_instances: List[Dict[str, Any]]) -> Optional[str]:
    """
    Find an available AttackBox instance.
    Priority: 1) Running and available, 2) Stopped (start it)
    """
    try:
        # Get all instances from ASG
        asg_instances = get_attackbox_pool_instances(asg_name)
        
        # Check pool table for availability
        available_ids = [inst['instance_id'] for inst in pool_instances if inst['status'] == 'available']
        
        # Find running available instance
        for instance in asg_instances:
            if instance['instance_id'] in available_ids and instance['state'] == 'running':
                logger.info(f"Found running available instance: {instance['instance_id']}")
                return instance['instance_id']
        
        # Find stopped instance to start
        for instance in asg_instances:
            if instance['instance_id'] in available_ids and instance['state'] == 'stopped':
                logger.info(f"Found stopped instance to start: {instance['instance_id']}")
                start_instance(instance['instance_id'])
                return instance['instance_id']
        
        logger.warning("No available AttackBox instances found")
        return None
    except Exception as e:
        logger.error(f"Failed to find available AttackBox: {str(e)}")
        raise


def tag_instance(instance_id: str, tags: Dict[str, str]) -> bool:
    """Add tags to an EC2 instance"""
    try:
        tag_list = [{'Key': k, 'Value': v} for k, v in tags.items()]
        ec2_client.create_tags(Resources=[instance_id], Tags=tag_list)
        logger.info(f"Tagged instance {instance_id} with {tags}")
        return True
    except Exception as e:
        logger.error(f"Failed to tag instance {instance_id}: {str(e)}")
        raise
