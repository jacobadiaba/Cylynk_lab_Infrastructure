"""
DynamoDB operations for session and pool management
"""
import boto3
from boto3.dynamodb.conditions import Key, Attr
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger()

dynamodb = boto3.resource('dynamodb')


class SessionManager:
    """Manage lab sessions in DynamoDB"""
    
    def __init__(self, table_name: str):
        self.table = dynamodb.Table(table_name)
    
    def create_session(self, session_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new session"""
        try:
            self.table.put_item(Item=session_data)
            logger.info(f"Created session: {session_data['session_id']}")
            return session_data
        except Exception as e:
            logger.error(f"Failed to create session: {str(e)}")
            raise
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session by ID"""
        try:
            response = self.table.get_item(Key={'session_id': session_id})
            return response.get('Item')
        except Exception as e:
            logger.error(f"Failed to get session {session_id}: {str(e)}")
            raise
    
    def update_session_status(self, session_id: str, status: str, 
                             additional_attrs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Update session status"""
        try:
            update_expr = "SET #status = :status, updated_at = :updated_at"
            expr_attr_names = {'#status': 'status'}
            expr_attr_values = {
                ':status': status,
                ':updated_at': int(datetime.utcnow().timestamp())
            }
            
            if additional_attrs:
                for key, value in additional_attrs.items():
                    update_expr += f", {key} = :{key}"
                    expr_attr_values[f":{key}"] = value
            
            response = self.table.update_item(
                Key={'session_id': session_id},
                UpdateExpression=update_expr,
                ExpressionAttributeNames=expr_attr_names,
                ExpressionAttributeValues=expr_attr_values,
                ReturnValues='ALL_NEW'
            )
            return response['Attributes']
        except Exception as e:
            logger.error(f"Failed to update session {session_id}: {str(e)}")
            raise
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session"""
        try:
            self.table.delete_item(Key={'session_id': session_id})
            logger.info(f"Deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Failed to delete session {session_id}: {str(e)}")
            raise
    
    def get_active_sessions_by_student(self, student_id: str) -> List[Dict[str, Any]]:
        """Get all active sessions for a student"""
        try:
            response = self.table.query(
                IndexName='StudentIndex',
                KeyConditionExpression=Key('student_id').eq(student_id),
                FilterExpression=Attr('status').eq('active')
            )
            return response.get('Items', [])
        except Exception as e:
            logger.error(f"Failed to get sessions for student {student_id}: {str(e)}")
            raise


class PoolManager:
    """Manage AttackBox pool in DynamoDB"""
    
    def __init__(self, table_name: str):
        self.table = dynamodb.Table(table_name)
    
    def register_instance(self, instance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Register an AttackBox instance in the pool"""
        try:
            self.table.put_item(Item=instance_data)
            logger.info(f"Registered instance: {instance_data['instance_id']}")
            return instance_data
        except Exception as e:
            logger.error(f"Failed to register instance: {str(e)}")
            raise
    
    def get_instance(self, instance_id: str) -> Optional[Dict[str, Any]]:
        """Get instance by ID"""
        try:
            response = self.table.get_item(Key={'instance_id': instance_id})
            return response.get('Item')
        except Exception as e:
            logger.error(f"Failed to get instance {instance_id}: {str(e)}")
            raise
    
    def get_available_instances(self) -> List[Dict[str, Any]]:
        """Get all available (ready) instances"""
        try:
            response = self.table.query(
                IndexName='StatusIndex',
                KeyConditionExpression=Key('status').eq('available')
            )
            return response.get('Items', [])
        except Exception as e:
            logger.error(f"Failed to get available instances: {str(e)}")
            raise
    
    def update_instance_status(self, instance_id: str, status: str, 
                              session_id: Optional[str] = None) -> Dict[str, Any]:
        """Update instance status"""
        try:
            update_expr = "SET #status = :status, last_used = :last_used"
            expr_attr_names = {'#status': 'status'}
            expr_attr_values = {
                ':status': status,
                ':last_used': int(datetime.utcnow().timestamp())
            }
            
            if session_id:
                update_expr += ", session_id = :session_id"
                expr_attr_values[':session_id'] = session_id
            
            response = self.table.update_item(
                Key={'instance_id': instance_id},
                UpdateExpression=update_expr,
                ExpressionAttributeNames=expr_attr_names,
                ExpressionAttributeValues=expr_attr_values,
                ReturnValues='ALL_NEW'
            )
            return response['Attributes']
        except Exception as e:
            logger.error(f"Failed to update instance {instance_id}: {str(e)}")
            raise
    
    def get_pool_stats(self) -> Dict[str, int]:
        """Get pool statistics"""
        try:
            # Scan all items (consider pagination for large pools)
            response = self.table.scan()
            items = response.get('Items', [])
            
            stats = {
                'total': len(items),
                'available': 0,
                'in_use': 0,
                'stopped': 0,
                'terminated': 0
            }
            
            for item in items:
                status = item.get('status', 'unknown')
                if status in stats:
                    stats[status] += 1
            
            return stats
        except Exception as e:
            logger.error(f"Failed to get pool stats: {str(e)}")
            raise
