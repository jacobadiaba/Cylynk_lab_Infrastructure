"""
Guacamole database operations for connection management
"""
import boto3
import json
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger()

secrets_client = boto3.client('secretsmanager')


def get_db_credentials(secret_arn: str) -> Dict[str, str]:
    """Retrieve Guacamole database credentials from Secrets Manager"""
    try:
        response = secrets_client.get_secret_value(SecretId=secret_arn)
        secret = json.loads(response['SecretString'])
        return secret
    except Exception as e:
        logger.error(f"Failed to retrieve DB credentials: {str(e)}")
        raise


def get_db_connection(secret_arn: str, db_host: str):
    """Create database connection to Guacamole PostgreSQL"""
    try:
        credentials = get_db_credentials(secret_arn)
        
        conn = psycopg2.connect(
            host=db_host,
            port=credentials.get('port', 5432),
            database=credentials.get('database', 'guacamole_db'),
            user=credentials.get('username'),
            password=credentials.get('password')
        )
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to Guacamole DB: {str(e)}")
        raise


def create_guacamole_connection(
    secret_arn: str,
    db_host: str,
    connection_name: str,
    protocol: str,
    hostname: str,
    port: int,
    username: str,
    password: str,
    session_id: str
) -> int:
    """
    Create a new connection in Guacamole database
    Returns connection_id
    """
    try:
        conn = get_db_connection(secret_arn, db_host)
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        # Insert into guacamole_connection table
        cursor.execute("""
            INSERT INTO guacamole_connection (connection_name, protocol, max_connections, max_connections_per_user)
            VALUES (%s, %s, 1, 1)
            RETURNING connection_id
        """, (connection_name, protocol))
        
        connection_id = cursor.fetchone()['connection_id']
        
        # Insert connection parameters
        parameters = {
            'hostname': hostname,
            'port': str(port),
            'username': username,
            'password': password
        }
        
        if protocol == 'rdp':
            parameters.update({
                'security': 'any',
                'ignore-cert': 'true',
                'enable-wallpaper': 'true'
            })
        elif protocol == 'vnc':
            parameters.update({
                'color-depth': '24'
            })
        
        for param_name, param_value in parameters.items():
            cursor.execute("""
                INSERT INTO guacamole_connection_parameter (connection_id, parameter_name, parameter_value)
                VALUES (%s, %s, %s)
            """, (connection_id, param_name, param_value))
        
        # Add session metadata as attribute
        cursor.execute("""
            INSERT INTO guacamole_connection_attribute (connection_id, attribute_name, attribute_value)
            VALUES (%s, 'session_id', %s)
        """, (connection_id, session_id))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Created Guacamole connection {connection_id} for session {session_id}")
        return connection_id
        
    except Exception as e:
        logger.error(f"Failed to create Guacamole connection: {str(e)}")
        raise


def delete_guacamole_connection(secret_arn: str, db_host: str, connection_id: int) -> bool:
    """Delete a connection from Guacamole database"""
    try:
        conn = get_db_connection(secret_arn, db_host)
        cursor = conn.cursor()
        
        # Delete connection parameters
        cursor.execute("""
            DELETE FROM guacamole_connection_parameter WHERE connection_id = %s
        """, (connection_id,))
        
        # Delete connection attributes
        cursor.execute("""
            DELETE FROM guacamole_connection_attribute WHERE connection_id = %s
        """, (connection_id,))
        
        # Delete connection
        cursor.execute("""
            DELETE FROM guacamole_connection WHERE connection_id = %s
        """, (connection_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Deleted Guacamole connection {connection_id}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to delete Guacamole connection: {str(e)}")
        raise


def get_connection_by_session(secret_arn: str, db_host: str, session_id: str) -> Optional[Dict[str, Any]]:
    """Find Guacamole connection by session_id attribute"""
    try:
        conn = get_db_connection(secret_arn, db_host)
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        cursor.execute("""
            SELECT c.connection_id, c.connection_name, c.protocol
            FROM guacamole_connection c
            JOIN guacamole_connection_attribute a ON c.connection_id = a.connection_id
            WHERE a.attribute_name = 'session_id' AND a.attribute_value = %s
        """, (session_id,))
        
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        
        return dict(result) if result else None
        
    except Exception as e:
        logger.error(f"Failed to get connection for session {session_id}: {str(e)}")
        raise
