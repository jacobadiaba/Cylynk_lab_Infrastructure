"""
Common utilities for orchestrator Lambda functions
"""
import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


class Response:
    """Helper class for API Gateway responses"""
    
    @staticmethod
    def success(data: Any, status_code: int = 200) -> Dict[str, Any]:
        """Return success response"""
        return {
            'statusCode': status_code,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key',
                'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
            },
            'body': json.dumps({
                'success': True,
                'data': data,
                'timestamp': datetime.utcnow().isoformat()
            })
        }
    
    @staticmethod
    def error(message: str, status_code: int = 400, error_type: str = 'BadRequest') -> Dict[str, Any]:
        """Return error response"""
        logger.error(f"{error_type}: {message}")
        return {
            'statusCode': status_code,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': {
                    'type': error_type,
                    'message': message
                },
                'timestamp': datetime.utcnow().isoformat()
            })
        }


def get_env_variable(name: str, default: Optional[str] = None) -> str:
    """Get environment variable with optional default"""
    value = os.environ.get(name, default)
    if value is None:
        raise ValueError(f"Environment variable {name} is required")
    return value


def calculate_ttl(hours: int = 24) -> int:
    """Calculate TTL timestamp for DynamoDB"""
    return int((datetime.utcnow() + timedelta(hours=hours)).timestamp())


def parse_request_body(event: Dict[str, Any]) -> Dict[str, Any]:
    """Parse and validate request body from API Gateway event"""
    try:
        if 'body' not in event:
            raise ValueError("Request body is missing")
        
        body = event['body']
        if isinstance(body, str):
            return json.loads(body)
        return body
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in request body: {str(e)}")


def get_path_parameter(event: Dict[str, Any], parameter_name: str) -> str:
    """Extract path parameter from API Gateway event"""
    path_params = event.get('pathParameters', {})
    if not path_params or parameter_name not in path_params:
        raise ValueError(f"Path parameter '{parameter_name}' is required")
    return path_params[parameter_name]


def get_query_parameter(event: Dict[str, Any], parameter_name: str, default: Optional[str] = None) -> Optional[str]:
    """Extract query parameter from API Gateway event"""
    query_params = event.get('queryStringParameters', {})
    if not query_params:
        return default
    return query_params.get(parameter_name, default)
